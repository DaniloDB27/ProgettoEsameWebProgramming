<?php

require_once 'auth.php';
if (!$userid = checkAuth()) exit;

header('Content-Type: application/json');

    $conn = mysqli_connect($dbconfig['host'], $dbconfig['user'], $dbconfig['password'], $dbconfig['name']);
   
    $userid = mysqli_real_escape_string($conn, $userid);

    $date = date("Y-m-d");
/*
    $query= "SELECT * from preferiti where utente= '".$userid."'";

    $res = mysqli_query($conn, $query);

    if(mysqli_num_rows($res) > 0){
      print_r($res);
      $array= mysqli_fetch_assoc($res);
      $json= json_encode($array);
      $query= "INSERT INTO preferiti(id, utente, chirurgo, nome, email, image, nomeR, ospedale, citta, date) VALUES('".$_GET['id']."','".$userid."', '".$_GET['id_chirurgo']."', '".$_GET['nomeC']."', '".$_GET['email']."', '".$_GET['imageC']."', '".$_GET['nomeR']."', '".$_GET['nome']."', '".$_GET['citta']."','".$date."')";
      $res1 = mysqli_query($conn, $query);
      print_r($res1);
      mysqli_free_result($res);
    
    }else{

      $query= "INSERT INTO preferiti(id, utente, chirurgo, nome, email, image, nomeR, ospedale, citta, date) VALUES(NULL,'".$userid."', '".$_GET['id_chirurgo']."', '".$_GET['nomeC']."', '".$_GET['email']."', '".$_GET['imageC']."', '".$_GET['nomeR']."', '".$_GET['ospedale']."', '".$_GET['citta']."','".$date."')";
      $res = mysqli_query($conn, $query);
      mysqli_free_result($res);

    }
    */
  

    $query= "INSERT INTO preferiti(id, utente, chirurgo, nome, email, image, nomeR, ospedale, citta, indirizzo, date) VALUES('".$_GET['id']."','".$userid."', '".$_GET['id_chirurgo']."', '".$_GET['nomeC']."', '".$_GET['email']."', '".$_GET['imageC']."', '".$_GET['nomeR']."', '".$_GET['nome']."', '".$_GET['citta']."', '".$_GET['indirizzo']."','".$date."')";
    $res = mysqli_query($conn, $query);
    mysqli_free_result($res);

    mysqli_close($conn);
    exit;

?>